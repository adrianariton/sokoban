main.py -> KBS(10)
lrta.py --> LRTA*