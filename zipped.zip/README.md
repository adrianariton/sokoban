main.ipynb -> KBS(10)
lrta.ipynb --> LRTA*
kbs20pa.ipynb -> KBS(20), w/ pulls allowed